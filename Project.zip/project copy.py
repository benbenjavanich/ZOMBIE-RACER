#Tasdiq Bashar and Benjamin James
#rdk3km and scm6en

import uvage

sh = 600
sw = 800

camera = uvage.Camera(sw, sh)

level_background = uvage.from_image(6000, sh//2, "alternative_image.png")
level_background.size=[12600, 600]


player_1_image = uvage.load_sprite_sheet("player_images.png",1,4)
player_1 = uvage.from_image(100,550,player_1_image[-1])
player_1.size=[60,60]
player_2_image = uvage.load_sprite_sheet("player2_images.png",1,4)
player_2 = uvage.from_image(100,550,player_2_image[-1])
player_2.size=[60,60]
current_frame = 0


player1_move = False
player2_move = False
speedup1 = 1
speedup2 = 1
facing_right1= True
facing_right2 = True
powered_up1 = False
powered_up2 = False
player_speed = 8

platforms = [
    uvage.from_image(1100, 450, "big_block.jpg"),
    uvage.from_image(700, 450, "normal_platform.jpg"),
    uvage.from_image(800, 450, "small_normal.jpg"),
    uvage.from_image(900, 450, "small_block.jpg"),
    uvage.from_image(1000, 450, "power_up.jpg"),
    uvage.from_image(1600, 350, "normal_platform.jpg"),
    uvage.from_image(1950, 320, "small_normal.jpg"),
    uvage.from_image(1850, 500, "small_normal.jpg"),
    uvage.from_image(2200, 450, "big_block.jpg"),
    uvage.from_image(2450, 275, "small_normal.jpg"),
    uvage.from_image(2600, 150, "small_normal.jpg"),
    uvage.from_image(2750, 350, "normal_platform.jpg"),
    uvage.from_image(3075, 200, "big_block.jpg"),
    uvage.from_image(3300, 550, "small_block.jpg"),
    uvage.from_image(3300, 250, "power_up.jpg"),
    uvage.from_image(3700, 350, "normal_platform.jpg"),
    uvage.from_image(4000, 400, "big_block.jpg"),
    uvage.from_image(4200, 325, "small_normal.jpg"),
    uvage.from_image(4300, 450, "small_normal.jpg"),
    uvage.from_image(4600, 0, "big_block.jpg"),
    uvage.from_image(4600, 350, "big_block.jpg"),
    uvage.from_image(4600, 550, "big_block.jpg"),
]

lavas = [
    uvage.from_color(300, 550, 'red', 50, 100),

    ]

spikes = [
    uvage.from_color(800, 350, 'dark red', 25, 25)

]

gold_coins = [
        uvage.from_color(3300, 200, "yellow", 12, 12),
        uvage.from_color(3500, 500, "yellow", 12, 12)
    ]

purple_coins = [
    uvage.from_color(500, 200, "purple", 12, 12),
    uvage.from_color(400, 500, "purple", 12, 12)
]

green_coins = [
    uvage.from_color(600, 200, "green", 12, 12),
    uvage.from_color(700, 500, "green", 12, 12)
]

game_over = False

timer = 70
timer_count = 0
tx = 0
powerup_timer1 = 3
powerup_timer2 = 3

health1 = 5
health2 = 5

def tick():
    global timer, timer_count, tx, game_over, player_speed, platforms
    global gold_coins, purple_coins, green_coins, powered_up1, powered_up2, powerup_timer1, powerup_timer2
    global player1_move, player2_move, speedup1, speedup2, facing_right1, facing_right2, current_frame
    global health1, health2, lavas, spikes


    #DRAWING
    camera.clear("black")
    camera.draw(level_background)
    camera.draw(player_1)
    camera.draw(player_2)
    camera.draw(uvage.from_text(tx-300, 50, "Timer " + str(timer), 50, "Yellow", bold=True))

    # PLATFORMS
    for platform in platforms:
        camera.draw(platform)
        player_1.move_to_stop_overlapping(platform)
        player_2.move_to_stop_overlapping(platform)

        if player_1.left_touches(platform) or player_1.right_touches(platform):
            player_1.move_to_stop_overlapping(platform)
        if player_1.bottom_touches(platform):
            if player_1.speedy == 0 and uvage.is_pressing("w"):
                player_1.speedy = -20

        if player_2.bottom_touches(platform):
            if player_2.speedy == 0 and uvage.is_pressing("up arrow"):
                player_2.speedy = -20
        if player_2.left_touches(platform) or player_2.right_touches(platform):
            player_2.move_to_stop_overlapping(platform)

    #MOVING CAMERA
    if player_1.x >= player_2.x:
        camera.x = player_1.x
        tx = player_1.x
    elif player_2.x >= player_1.x:
        camera.x = player_2.x
        tx = player_2.x

    player_1.yspeed += 1
    player_2.yspeed += 1

    #FLOOR
    floor = uvage.from_color(2500, 610, 'black', 30000, 40)
    camera.draw(floor)

    player_1.move_to_stop_overlapping(floor)
    player_2.move_to_stop_overlapping(floor)

    camera.draw(uvage.from_text(tx - 300, 50, "Timer " + str(timer), 50, "yellow", bold=True))

    #INPUT
    if game_over == False:
        if uvage.is_pressing("a"):
            player_1.x -= player_speed * speedup1
            if facing_right1:
                facing_right1 = False
                player_1.flip()
            player1_move = True

        if uvage.is_pressing("d"):
            player_1.x += player_speed * speedup1
            if not facing_right1:
                facing_right1 = True
                player_1.flip()
            player1_move = True

        if player_1.touches(floor):
            if uvage.is_pressing("w"):
                player_1.speedy -= 20

        if uvage.is_pressing("left arrow"):
            player_2.x -= player_speed * speedup2
            if facing_right2:
                facing_right2 = False
                player_2.flip()
            player2_move = True

        if uvage.is_pressing("right arrow"):
            player_2.x += player_speed * speedup2
            if not facing_right2:
                facing_right2 = True
                player_2.flip()
            player2_move = True

        if player_2.touches(floor):
            if uvage.is_pressing("up arrow"):
                player_2.speedy -= 20

    #Sprite
    if player1_move:
        current_frame += 0.29
        if current_frame >= 4:
            current_frame = 0
        player_1.image = player_1_image[int(current_frame)]
    else:
        player_1.image = player_1_image[1]

    if player2_move:
        current_frame += 0.29
        if current_frame >= 4:
            current_frame = 0
        player_2.image = player_2_image[int(current_frame)]
    else:
        player_2.image = player_2_image[1]

    player_1.move_speed()
    player_2.move_speed()

    # TIMER
    timer_count -= 1
    if timer_count % 30 == 0 and game_over == False:
        timer -= 1
        if powered_up1:
            powerup_timer1 -= 1
        if powered_up2:
            powerup_timer2 -= 1

    #Health
    camera.draw(uvage.from_text(tx+300, 50, "Health " + str(health1), 40, "Red", bold=True))
    camera.draw(uvage.from_text(tx+300, 80, "Health " + str(health2), 40, "Blue", bold=True))

    #Powerups
    for Gcoin in gold_coins:
        if player_1.touches(Gcoin):
            gold_coins.remove(Gcoin)
            powerup_timer1 = 3
            powered_up1 = True
            if powered_up1:
                speedup1 += 1
        if player_2.touches(Gcoin):
            gold_coins.remove(Gcoin)
            powerup_timer2 = 3
            powered_up2 = True
            if powered_up2:
                speedup2 += 1
        camera.draw(Gcoin)

    for Pcoin in purple_coins:
        if player_1.touches(Pcoin):
            purple_coins.remove(Pcoin)
            player_1.x = player_2.x
            player_1.y = player_2.y
        if player_2.touches(Pcoin):
            purple_coins.remove(Pcoin)
            player_2.x = player_1.x
            player_2.y = player_1.y
        camera.draw(Pcoin)
    
    for Hcoin in green_coins:
        if player_1.touches(Hcoin):
            green_coins.remove(Hcoin)
            health1 += 1
        if player_2.touches(Hcoin):
            green_coins.remove(Hcoin)
            health2 += 1
        camera.draw(Hcoin)

    #Traps
    for lava in lavas:
        camera.draw(lava)
        player_1.move_to_stop_overlapping(lava)
        player_2.move_to_stop_overlapping(lava)
        if player_1.touches(lava) and timer_count % 30 == 0:
            health1 -= 1
        if player_2.touches(lava) and timer_count % 30 == 0:
            health2 -= 1
        
        if player_1.left_touches(lava) or player_1.right_touches(lava):
            player_1.move_to_stop_overlapping(platform)
        if player_1.bottom_touches(lava):
            if player_1.speedy == 0 and uvage.is_pressing("w"):
                player_1.speedy = -20

        if player_2.bottom_touches(lava):
            if player_2.speedy == 0 and uvage.is_pressing("up arrow"):
                player_2.speedy = -20
        if player_2.left_touches(lava) or player_2.right_touches(lava):
            player_2.move_to_stop_overlapping(lava)
    
    for spike in spikes:
        camera.draw(spike)
        if player_1.touches(spike):
            spikes.remove(spike)
            health1 -= 2
        if player_2.touches(spike):
            spikes.remove(spike)
            health2 -= 2


    #GAME OVER
    flag = uvage.from_color(11500, 550, 'black', 50, 100)
    camera.draw(flag)
    player_1.move_to_stop_overlapping(flag)
    player_2.move_to_stop_overlapping(flag)
    if health1 == 0 or health2 == 0:
        game_over = True
        if game_over:
            timer -= 0
            if health2 == 0:
                winner_1 = uvage.from_text(tx, 300, 'Red Wins!', 50, 'Red', True, True)
                camera.draw(winner_1)
            elif health1 == 0:
                winner_2 = uvage.from_text(tx, 300, 'Blue Wins!', 50, 'Blue', True, True)
                camera.draw(winner_2)
    if timer == 0 or player_1.touches(flag) or player_2.touches(flag):
            # or player_1.x < (player_2.x - 410) or player_2.x < (player_1.x - 410):
        game_over = True
        if game_over:
            timer -= 0
            if player_1.touches(flag) or player_1.x > player_2.x:
                winner_1 = uvage.from_text(tx, 300, 'Red Wins!', 50, 'Red', True, True)
                camera.draw(winner_1)
            elif player_2.touches(flag) or player_2.x > player_1.x:
                winner_2 = uvage.from_text(tx, 300, 'Blue Wins!', 50, 'Blue', True, True)
                camera.draw(winner_2)
            elif player_1.x == player_2.x:
                draw = uvage.from_text(tx, 300, 'Tie!', 50, 'Purple', True, True)
                camera.draw(draw)
    if game_over:
        restart = uvage.from_text(tx, 350, 'press space to restart', 40, 'black', True, True)
        camera.draw(restart)
        if uvage.is_pressing('space'):
            game_over = False
            timer = 70
            player_1.x = 130
            player_2.x = 80
            player_1.y = 550
            player_2.y = 550
            health1 = 5
            health2 = 5
    camera.display()


ticks_per_second = 30
uvage.timer_loop(ticks_per_second, tick)